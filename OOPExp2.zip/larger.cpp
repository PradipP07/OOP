#include<iostream>
using namespace std;
int main(){
	float a,b,c;
	cout<<"enter three no.s:\n";
	cin>>a>>b>>c;
	if(a>b){
		if(a>c)
		cout<<"\n"<<a<<"is larger";
	}else if(b>c){
		cout<<"\n"<<b<<"is larger";
	}else{
		cout<<"\n"<<c<<"is larger";
	}
}
