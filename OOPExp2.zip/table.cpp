#include<iostream>
using namespace std;
int main(){
	float a;
	cout<<"enter no.:\n";
	cin>>a;
	for(int i=1;i<11;i++){
		cout<<"\n"<<a*i;
	}
}
