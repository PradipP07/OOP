#include<iostream>
using namespace std;
int main(){
	float a,b,z;
	double d;
	cout<<"enter values of a%b:\n";
	cin>>a>>b;
	z=a+b;
	cout<<"\nsum="<<z;
	z=a-b;
	cout<<"\nsub="<<z;
	z=a*b;
	cout<<"\nmultiply="<<z;
    d=(a/b);
	cout<<"\ndiv="<<d;
	int m=(int)a%(int)b;
	cout<<"\nmod="<<m;
}
